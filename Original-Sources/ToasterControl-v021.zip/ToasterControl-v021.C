/*
    4-26-05
    Copyright Spark Fun Electronics� 2005
    Nathan Seidle 
    spark@sparkfun.com
    
    Basic control and monitoring of a Toaster oven for SMD reflowing.

    The unit responds to these commands:
    
    0x31 ('1') - Relay On : Activates the heating elements
    0x32 ('2') - Relay Off : Deactivates the heating elements
    
    0x63 ('c') - Temperature Check : Unit takes a temperature reading and responds with the 10-bit reading in two bytes
    0x74 ('t') - Time Check : Unit reports total seconds run (ex: 138)
    0x72 ('r') - Reset Time : Resets the total seconds.
    
    Safety settings : The reflow toaster controller will shut off the relay if it does not 
    receive the Relay On command after 30 seconds.
    
    This is a really nice example program that includes examples on how to do the following:
    Standard HD44780 parallel interface to LCD
    Print decimal numbers and strings to serial output as well as an LCD
    Reading buttons
    Real time clock (RTC) interrupts using an internal osc (not very accurate, but it works)
    Doing an ADC on a thermocouple to get temperature
    EEPROM Read and Write functions are also available for storing profiles
    Oh, and of course we blink the Status LED

    I've pulled all the functions into this one file for all of you who want to wade through the code.

    We use a simple, cheap, thermocouple with the expensive AD595AQ Amplifier
    
*/
//#define Clock_8MHz
//#define Baud_9600

#define STATUS_LED      PORTB.3

#define BUTTON_UP       PORTB.0
#define BUTTON_DOWN     PORTB.1
#define BUTTON_SELECT   PORTB.7

#define RELAY           PORTB.4

#define OFF 0
#define ON  1

#define D7              PORTA.3
#define D6              PORTA.2
#define D5              PORTA.1
#define D4              PORTA.0
#define E               PORTA.7
#define R_W             PORTA.6
#define RS              PORTB.6

#define     CLR_DISP        0b.0000.0001 //Clear display
#define     CUR_HOME        0b.0000.0010    //Move cursor home and clear screen memory
#define     DISP_ON         0b.0000.1100    //Turn visible LCD on
#define     SET_CURSOR      0b.1000.0000    //SET_CURSOR + X : Sets cursor position to X


#include "\Global\Code\C\16F88.h" // Device hardware map
#include "\Global\Code\C\int16CXX.H" // Device interrupt definitions

//#pragma config |= 0x2902
#pragma origin 4 //Used for boot loading and interrupts

//Global Variables
//============================
uns8 m_seconds;
uns8 seconds;
uns16 total_seconds; //Used in VB for thresholds
//============================
//End Global Variables

//Interrupt Vectors
//============================
interrupt serverX( void)
{
    int_save_registers
    char sv_FSR = FSR;  // save FSR if required

    if(TMR1IF) //Timer1 Overflow Interrupt
    {
        //Setup Timer1 to fire every 100ms
        //1 TMR1 click is 4us (with prescaler of 8). 100ms / .004ms = 25000 clicks
        //65535 - 25000 = 40535 = 0x9E57
        TMR1ON = 0; TMR1H = 0x9E; TMR1L = 0x57; TMR1ON = 1;

        m_seconds++;
        if(m_seconds == 10)
        {
            m_seconds = 0;
            seconds++;
            total_seconds++;
        }

        TMR1IF = 0; //Clear INT Flag
    }

    FSR = sv_FSR;               // restore FSR if saved
    int_restore_registers 
}
//============================

//Function definitions
//============================
//#include "d:\Pics\code\Delay.c"   // Delays
//#include "d:\Pics\code\Stdio.c"   // Print routines

void boot_up(void);
uns16 check_temp(void);
void delay_ms(uns16 x);

void send_char(uns8);
void send_cmd(uns8);
//void send_string(const char* incoming_string);
void LCD_wait(void);
void init_lcd(void);
void printf_lcd(const char *nate, int16 my_byte);

void putc(uns8);
uns8 getc(void);
uns8 scanc(void);
uns8 bin2Hex(char x);
void printf(const char *nate, int16 my_byte);

//============================
//End Function Definitions

void main()
{
    uns8 choice;
    uns16 adc_reading;
    uns24 temperature;
    
    boot_up();
    
    while(1)
    {
        if(seconds > 30)
        {
            RELAY = OFF;

            printf("Emergency shut down", 0);

            send_cmd(CLR_DISP);
            printf_lcd("Emergency                               shut down", 0);

            while(1)
            {
                STATUS_LED ^= 1;
                delay_ms(500);
            }
        }
        
        //Scan for buttons as we wait
        //====================================================
        if(BUTTON_SELECT == 0)
        {
            while(BUTTON_SELECT == 0); //Wait for user to remove finger
            
            send_cmd(CLR_DISP);
            printf_lcd("Select", 0);

            printf("#SELECT$", 0);
        }
        if(BUTTON_UP == 0)
        {
            while(BUTTON_UP == 0); //Wait for user to remove finger
            
            send_cmd(CLR_DISP);
            printf_lcd("Up", 0);

            printf("#UP$", 0);
        }
        if(BUTTON_DOWN == 0)
        {
            while(BUTTON_DOWN == 0); //Wait for user to remove finger
            
            send_cmd(CLR_DISP);
            printf_lcd("Down", 0);

            printf("#DOWN$", 0);
        }
        //====================================================
        
        //Check for an incoming serial command
        //====================================================
        if(RCIF)
        {
            choice = RCREG;

            seconds = 0; //Reset the emergency shutdown time-out


            if(choice == 'c') //Check temp
            {
                adc_reading = check_temp();
    
                temperature = adc_reading * (uns24)5000; //75 * 5000 = 375000
                temperature /= 1024; //375000 / 1024 = 366mV
                //temperature /= 10; //366mV / 10mV/C = 36.6C = 97.88F
                
                printf("#%d$", temperature); //Reports temp in mV

                //Now make it pretty for the LCD
                //====================================================
                send_cmd(CLR_DISP);
                printf_lcd("Temp=", 0);

                uns8 digit_100s, digit_10s, digit_1s;
                
                digit_100s = temperature / 100;

                temperature %= 100; //Mod operator to cut off the 100s from temperature variable
                digit_10s = temperature / 10;
                

                temperature %= 10;
                digit_1s = temperature;

                printf_lcd("%d", digit_100s);
                printf_lcd("%d.", digit_10s);
                printf_lcd("%dC", digit_1s);
                //====================================================
            }
    
            if(choice == 't') //Check time
            {
                send_cmd(CLR_DISP);
                printf_lcd("Time=%d", total_seconds);

                printf("#%d$", total_seconds); 
            }
    
            if(choice == 'r') //Reset time
            {
                m_seconds = 0;
                seconds = 0;
                total_seconds = 0;
    
                send_cmd(CLR_DISP);
                printf_lcd("Time Reset", 0);

                printf("#OK$", 0);
            }
    
            if(choice == '1') //Turn on oven
            {
                send_cmd(CLR_DISP);
                printf_lcd("Relay On", 0);

                printf("#ON$", 0);
                RELAY = ON;
            }
    
            if(choice == '2') //Turn off oven
            {
                send_cmd(CLR_DISP);
                printf_lcd("Relay Off", 0);

                printf("#OFF$", 0);
                RELAY = OFF;
            }
            
            STATUS_LED ^= 1;
        }
        //====================================================


    }
    
}//End Main

//Init vars and ports
void boot_up(void)
{
    
    OSCCON = 0b.0111.0000; //Setup internal OSC to 8MHz
    
    ANSEL = 0b.0001.0000; //Turn RA4/AN4 to Analog
    
    PORTA = 0b.0000.0000;
    TRISA = 0b.0001.0000;  //0 = Output, 1 = Input (Temp on RA4)

    PORTB = 0b.1000.0111;
    TRISB = 0b.1000.0111;  //0 = Output, 1 = Input (RX on RB2) (Up on RB0, Down on RB1, Select on RB7)
    
    OPTION.7 = 0; //RBPU = 0 - Enabled PORTB Internal Pull-ups
    
    //Setup the hardware UART module
    //=============================================================
    SPBRG = 51; //8MHz for 9600 inital communication baud rate
    TXSTA = 0b.0010.0100; //8-bit asych mode, high speed uart enabled
    RCSTA = 0b.1001.0000; //Serial port enable, 8-bit asych continous receive mode
    //=============================================================

    //Make sure the oven is off at startup
    RELAY = OFF;

    //Reset time
    m_seconds = 0;
    seconds = 0;
    total_seconds = 0;
    
    //Setup Timer1 for delay between measurements
    T1CON = 0b.0011.0000; //Prescale of 1:8 - 1 timer click = 4us with 8MHz internal osc
    
    //Setup interrupts
    TMR1IE = 1;
    PEIE = 1;
    GIE = 1;
    
    TMR1ON = 1;
    
    init_lcd();

    printf_lcd(" SparkFun.com", 0);
    send_cmd(SET_CURSOR + 64);
    printf_lcd("ReflowToaster v2", 0);
    delay_ms(750);
    send_cmd(CLR_DISP);

}    


//Initializes the 4-bit parallel interface to the HD44780
void init_lcd(void)
{
    //Wait for LCD busy bit to clear
    LCD_wait();
    
    RS = 0;               
    R_W = 0;

    //Tell the LCD we are using 4bit data communication
    //===============================================================
    delay_ms(100);
    PORTA = 0b.0000.0011;
    E = 1; E = 0;

    delay_ms(50);
    PORTA = 0b.0000.0011;
    E = 1; E = 0;

    delay_ms(10);
    PORTA = 0b.0000.0011;
    E = 1; E = 0;

    delay_ms(10);
    PORTA = 0b.0000.0010;
    E = 1; E = 0;

    send_cmd(DISP_ON);
    send_cmd(CLR_DISP);
    //===============================================================
    
//    cursor_position = 0;
} 

//Checks the busy flag and waits until LCD is ready for next command
void LCD_wait(void)
{
    bit i = 1;
    
    TRISA = 0b.0001.1111;

    R_W = 1; //Tell LCD to output status
    RS = 0;               

    while(i == 1)
    {
        E = 1; 
        i = D7; //Read data bit 7 - Busy Flag
        E = 0;
    
        E = 1; E = 0; //Toggle E to get the second four bits of the status byte - but we don't care
    }
    
    TRISA = 0b.0001.0000; //0 = Output, 1 = Input (TEMP on RA4)
}

//Sends an ASCII character to the LCD
void send_char(uns8 c)
{
    LCD_wait();
    
    R_W = 0; //set LCD to write
    RS = 1; //set LCD to data mode
    
    D7 = c.7;
    D6 = c.6;
    D5 = c.5;
    D4 = c.4;
    E = 1; E = 0; //Toggle the Enable Pin

    D7 = c.3;
    D6 = c.2;
    D5 = c.1;
    D4 = c.0;
    E = 1; E = 0;
}

//Sends an LCD command
void send_cmd(uns8 d)
{
    LCD_wait();

    //TRISC = 0b.0000.0000;   //0 = Output, 1 = Input

    R_W = 0; //set LCD to write

    D7 = d.7;
    D6 = d.6;
    D5 = d.5;
    D4 = d.4;
    E = 1; E = 0;

    D7 = d.3;
    D6 = d.2;
    D5 = d.1;
    D4 = d.0;
    E = 1; E = 0;
}

//Sends a given string to the LCD. Will start printing from
//current cursor position.
/*
void send_string(const char *incoming_string)
{
    uns8 x;
    
    for(x = 0 ; incoming_string[x] != '\0' ; x++)
        send_char(incoming_string[x]);
}
*/

//Returns the current temperature
#define AVG_AMT 16
uns16 check_temp(void)
{
    uns8 x;
    uns16 amount, total = 0;

    //Read Channel 4
    ADCON0 = 0b.0110.0001; //Select Fosc/16 for 8mhz, and channel RA4/AN4, A/D on
    ADCON1 = 0b.1100.0000; //Right justified, ADCS2 = 1 

    for(x = 0 ; x < AVG_AMT ; x++)
    {
        delay_ms(1);
        
        GO = 1; //Convert RA1 to digital
    
        while(GO == 1);
    
        amount.high8 = ADRESH;
        amount.low8 = ADRESL;
        
        total += amount; //Add on to the total
    }
    amount = total / AVG_AMT;
    
    return(amount);
}

//Reads e_data from the onboard eeprom at e_address
uns8 onboard_eeread(uns8 e_address)
{
    EEPGD = 0; //Point to EEPROM Memory

    //Do a read
    EEADR = e_address; //Set the address to read
    RD = 1; //Read it
    
    return(EEDATA); //Read that EEPROM value
}    

//Write e_data to the onboard eeprom at e_address
void onboard_eewrite(uns8 e_data, uns8 e_address)
{
    bit temp_GIE = GIE;
    
    EEPGD = 0; //Point to EEPROM data block
    FREE = 0; //Preform write only  

    EEIF = 0; //Clear the write completion intr flag
    EEADR = e_address; //Set the address
    EEDATA = e_data; //Give it the data
    WREN = 1; //Enable EE Writes
    GIE = 0; //Disable Intrs
    
    //Specific EEPROM write steps
    EECON2 = 0x55;
    EECON2 = 0xAA;
    WR = 1;
    //Specific EEPROM write steps

    while(EEIF == 0); //Wait for write to complete
    EEIF = 0; //Clear the write completion intr flag

    WREN = 0; //Disable EEPROM Writes

    GIE = temp_GIE; //Set GIE to its original state
}

//Sends nate to the Transmit Register
void putc(uns8 nate)
{
    while(TXIF == 0);
    TXREG = nate;
}

uns8 getc(void)
{
    while(RCIF == 0);
    return (RCREG);
}    

uns8 scanc(void)
{
    uns16 counter = 0;
    
    while(RCIF == 0)
    {
        counter++;
        if(counter == 1000) return 0;
    }
    
    return (RCREG);
}    

//Returns ASCII Decimal and Hex values
uns8 bin2Hex(char x)
{
   skip(x);
   #pragma return[16] = "0123456789ABCDEF"
}

//Prints a string including variables
void printf(const char *nate, int16 my_byte)
{
  
    uns8 i, k, m, temp;
    uns8 high_byte = 0, low_byte = 0;
    uns8 y, z;
    
    uns8 decimal_output[5];
    
    for(i = 0 ; ; i++)
    {
        //delay_ms(3);
        
        k = nate[i];

        if (k == '\0') 
            break;

        else if (k == '%') //Print var
        {
            i++;
            k = nate[i];

            if (k == '\0') 
                break;
            else if (k == '\\') //Print special characters
            {
                i++;
                k = nate[i];
                
                putc(k);
                

            } //End Special Characters
            else if (k == 'b') //Print Binary
            {
                for( m = 0 ; m < 8 ; m++ )
                {
                    if (my_byte.7 == 1) putc('1');
                    if (my_byte.7 == 0) putc('0');
                    if (m == 3) putc(' ');
                    
                    my_byte = my_byte << 1;
                }
            } //End Binary               
            else if (k == 'd') //Print Decimal
            {
                //Print negative sign and take 2's compliment
                
                if(my_byte < 0)
                {
                    putc('-');
                    my_byte *= -1;
                }
                
                
                if (my_byte == 0)
                    putc('0');
                else
                {
                    //Divide number by a series of 10s
                    for(m = 4 ; my_byte > 0 ; m--)
                    {
                        temp = my_byte % (uns16)10;
                        decimal_output[m] = temp;
                        my_byte = my_byte / (uns16)10;               
                    }
                
                    for(m++ ; m < 5 ; m++)
                        putc(bin2Hex(decimal_output[m]));
                }
    
            } //End Decimal
            else if (k == 'h') //Print Hex
            {
                //New trick 3-15-04
                putc('0');
                putc('x');
                
                if(my_byte > 0x00FF)
                {
                    putc(bin2Hex(my_byte.high8 >> 4));
                    putc(bin2Hex(my_byte.high8 & 0b.0000.1111));
                }

                putc(bin2Hex(my_byte.low8 >> 4));
                putc(bin2Hex(my_byte.low8 & 0b.0000.1111));

                /*high_byte.3 = my_byte.7;
                high_byte.2 = my_byte.6;
                high_byte.1 = my_byte.5;
                high_byte.0 = my_byte.4;
            
                low_byte.3 = my_byte.3;
                low_byte.2 = my_byte.2;
                low_byte.1 = my_byte.1;
                low_byte.0 = my_byte.0;
        
                putc('0');
                putc('x');
            
                putc(bin2Hex(high_byte));
                putc(bin2Hex(low_byte));*/
            } //End Hex
            else if (k == 'f') //Print Float
            {
                putc('!');
            } //End Float
            else if (k == 'u') //Print Direct Character
            {
                //All ascii characters below 20 are special and screwy characters
                //if(my_byte > 20) 
                    putc(my_byte);
            } //End Direct
                        
        } //End Special Chars           

        else
            putc(k);
    }    
}

//Prints a string to the LCD including variables
void printf_lcd(const char *nate, int16 my_byte)
{
  
    uns8 i, k, m, temp;
    uns8 high_byte = 0, low_byte = 0;
    uns8 y, z;
    
    uns8 decimal_output[5];
    
    for(i = 0 ; ; i++)
    {
        //delay_ms(3);
        
        k = nate[i];

        if (k == '\0') 
            break;

        else if (k == '%') //Print var
        {
            i++;
            k = nate[i];

            if (k == '\0') 
                break;
            else if (k == '\\') //Print special characters
            {
                i++;
                k = nate[i];
                
                send_char(k);
                

            } //End Special Characters
            else if (k == 'b') //Print Binary
            {
                for( m = 0 ; m < 8 ; m++ )
                {
                    if (my_byte.7 == 1) send_char('1');
                    if (my_byte.7 == 0) send_char('0');
                    if (m == 3) send_char(' ');
                    
                    my_byte = my_byte << 1;
                }
            } //End Binary               
            else if (k == 'd') //Print Decimal
            {
                //Print negative sign and take 2's compliment
                
                if(my_byte < 0)
                {
                    send_char('-');
                    my_byte *= -1;
                }
                
                
                if (my_byte == 0)
                    send_char('0');
                else
                {
                    //Divide number by a series of 10s
                    for(m = 4 ; my_byte > 0 ; m--)
                    {
                        temp = my_byte % (uns16)10;
                        decimal_output[m] = temp;
                        my_byte = my_byte / (uns16)10;               
                    }
                
                    for(m++ ; m < 5 ; m++)
                        send_char(bin2Hex(decimal_output[m]));
                }
    
            } //End Decimal
            else if (k == 'h') //Print Hex
            {
                //New trick 3-15-04
                send_char('0');
                send_char('x');
                
                if(my_byte > 0x00FF)
                {
                    send_char(bin2Hex(my_byte.high8 >> 4));
                    send_char(bin2Hex(my_byte.high8 & 0b.0000.1111));
                }

                send_char(bin2Hex(my_byte.low8 >> 4));
                send_char(bin2Hex(my_byte.low8 & 0b.0000.1111));

                /*high_byte.3 = my_byte.7;
                high_byte.2 = my_byte.6;
                high_byte.1 = my_byte.5;
                high_byte.0 = my_byte.4;
            
                low_byte.3 = my_byte.3;
                low_byte.2 = my_byte.2;
                low_byte.1 = my_byte.1;
                low_byte.0 = my_byte.0;
        
                putc('0');
                putc('x');
            
                putc(bin2Hex(high_byte));
                putc(bin2Hex(low_byte));*/
            } //End Hex
            else if (k == 'u') //Print Direct Character
            {
                //All ascii characters below 20 are special and screwy characters
                //if(my_byte > 20) 
                    send_char(my_byte);
            } //End Direct
                        
        } //End Special Chars           

        else
            send_char(k);
    }    
}

//General short delay
void delay_ms(uns16 x)
{
    //Clocks out at 1006us per 1ms
    uns8 y, z;
    for ( ; x > 0 ; x--)
        for ( y = 0 ; y < 4 ; y++)
            for ( z = 0 ; z < 69 ; z++);

}